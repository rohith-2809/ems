// utils/localStorage.js

const employees = [
  {
    id: 1,
    email: "aarav@gmail.com",
    password: "123",
    firstname: "Aarav",
    taskNumbers: {
      active: 2,
      newTask: 1,
      completed: 1,
      failed: 0,
    },
    tasks: [
      {
        id: 1,
        title: "Complete report",
        date: "2024-11-14",
        description: "Prepare the quarterly report.",
        category: "Report",
        active: true,
        newTask: false,
        completed: false,
        failed: false,
      },
      {
        id: 2,
        title: "Team meeting",
        date: "2024-11-15",
        description: "Weekly team sync-up.",
        category: "Meeting",
        active: true,
        newTask: true,
        completed: false,
        failed: false,
      },
      {
        id: 3,
        title: "Code review",
        date: "2024-11-16",
        description: "Review code for the new feature.",
        category: "Development",
        active: false,
        newTask: false,
        completed: true,
        failed: false,
      },
    ],
  },
  {
    id: 2,
    email: "f",
    password: "123",
    firstname: "Ananya",
    taskNumbers: {
      active: 2,
      newTask: 1,
      completed: 1,
      failed: 1,
    },
    tasks: [
      {
        id: 1,
        title: "Client presentation",
        date: "2024-11-14",
        description: "Present Q3 results to the client.",
        category: "Presentation",
        active: true,
        newTask: true,
        completed: false,
        failed: false,
      },
      {
        id: 2,
        title: "Document updates",
        date: "2024-11-15",
        description: "Update project documentation.",
        category: "Documentation",
        active: true,
        newTask: false,
        completed: false,
        failed: true,
      },
      {
        id: 3,
        title: "Bug fixing",
        date: "2024-11-16",
        description: "Fix bugs reported in testing.",
        category: "Development",
        active: false,
        newTask: false,
        completed: true,
        failed: false,
      },
    ],
  },
  {
    id: 3,
    email: "vihaan@gmail.com",
    password: "123",
    firstname: "Vihaan",
    taskNumbers: {
      active: 2,
      newTask: 1,
      completed: 0,
      failed: 0,
    },
    tasks: [
      {
        id: 1,
        title: "Training session",
        date: "2024-11-14",
        description: "Conduct training for new hires.",
        category: "Training",
        active: true,
        newTask: false,
        completed: false,
        failed: false,
      },
      {
        id: 2,
        title: "Research",
        date: "2024-11-15",
        description: "Research new market trends.",
        category: "Research",
        active: true,
        newTask: true,
        completed: false,
        failed: false,
      },
    ],
  },
  {
    id: 4,
    email: "ishita@gmail.com",
    password: "123",
    firstname: "Ishita",
    taskNumbers: {
      active: 1,
      newTask: 0,
      completed: 1,
      failed: 0,
    },
    tasks: [
      {
        id: 1,
        title: "System upgrade",
        date: "2024-11-14",
        description: "Upgrade company systems to the latest version.",
        category: "IT",
        active: true,
        newTask: false,
        completed: false,
        failed: false,
      },
      {
        id: 2,
        title: "Inventory check",
        date: "2024-11-15",
        description: "Conduct an inventory check for office supplies.",
        category: "Logistics",
        active: false,
        newTask: false,
        completed: true,
        failed: false,
      },
    ],
  },
  {
    id: 5,
    email: "kavya@gmail.com",
    password: "123",
    firstname: "Kavya",
    taskNumbers: {
      active: 1,
      newTask: 1,
      completed: 1,
      failed: 1,
    },
    tasks: [
      {
        id: 1,
        title: "Design review",
        date: "2024-11-14",
        description: "Review new designs with the design team.",
        category: "Design",
        active: true,
        newTask: true,
        completed: false,
        failed: false,
      },
      {
        id: 2,
        title: "Budget planning",
        date: "2024-11-15",
        description: "Plan the budget for the next quarter.",
        category: "Finance",
        active: false,
        newTask: false,
        completed: true,
        failed: true,
      },
    ],
  },
];

const admin = [
  {
    id: 1,
    email: "admin@example.com",
    password: "123",
  },
];

// Function to set initial data in localStorage
export const SetLocalStorage = () => {
  localStorage.setItem("employees", JSON.stringify(employees));
  localStorage.setItem("admin", JSON.stringify(admin));
};

// Function to get data from localStorage, initializing if necessary
export const getLocalStorage = () => {
  let employees = JSON.parse(localStorage.getItem("employees"));
  let admin = JSON.parse(localStorage.getItem("admin"));

  // Initialize localStorage with SetLocalStorage if no data is found
  if (!employees || !admin) {
    SetLocalStorage();
    employees = JSON.parse(localStorage.getItem("employees"));
    admin = JSON.parse(localStorage.getItem("admin"));
  }

  return { employees, admin };
};
