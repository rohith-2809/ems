// context/AuthProvider.jsx
import React, { createContext, useEffect, useState } from "react";
import { getLocalStorage, SetLocalStorage } from "../utils/localStorage";

// Create the AuthContext
export const AuthContext = createContext();

const AuthProvider = ({ children }) => {
  const [authData, setUserData] = useState({ employees: [], admin: [] });

  useEffect(() => {
    // Retrieve data from localStorage, initializing if necessary
    SetLocalStorage();
    const { employees, admin } = getLocalStorage();
    setUserData({ employees, admin });
  }, []);

  return (
    <AuthContext.Provider value={authData}>{children}</AuthContext.Provider>
  );
};

export default AuthProvider;
