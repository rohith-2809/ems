import React from "react";
import AllTask from "../others/AllTask";
import CreateTask from "../others/CreateTask";
import Header from "../others/Header";
const AdminDashboard = (props) => {
  return (
    <div className="h-screen w-full p-10 bg-[#1c1c1c]">
      <Header changeUser={props.changeUser}/>
      <CreateTask />
      <AllTask />
    </div>
  );
};

export default AdminDashboard;
