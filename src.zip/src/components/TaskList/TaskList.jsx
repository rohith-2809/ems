import React from "react";
import AcceptTask from "./AcceptTask";
import CompleteTask from "./CompleteTask";
import FailedTask from "./FailedTask";
import NewTask from "./NewTask";

const TaskList = ({ data }) => {
  return (
    <div
      id="tasklist"
      className="h-[55%] overflow-x-auto flex flex-row items-center gap-5 w-full mt-10 py-5 mx-11"
    >
      {/* Task Cards */}
      {data.tasks.map((task) => {
        const { id, active, newTask, completed, failed } = task;

        // Render based on priority or mutually exclusive flags
        if (active) {
          return <AcceptTask key={id} data={task} />;
        } else if (newTask) {
          return <NewTask key={id} data={task} />;
        } else if (completed) {
          return <CompleteTask key={id} data={task} />;
        } else if (failed) {
          return <FailedTask key={id} data={task} />;
        }

        // Optional fallback for unmatched cases
        return null;
      })}
    </div>
  );
};

export default TaskList;
