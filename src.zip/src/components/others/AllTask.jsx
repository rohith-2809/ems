import React, { useContext } from "react";
import { AuthContext } from "../../context/AuthProvider";

const AllTask = () => {
  const authData = useContext(AuthContext); // Access data from the AuthProvider
  const { employees } = authData;

  return (
    <div className="bg-[#1c1c1c] p-5 rounded mt-5 overflow-auto">
      {employees.length > 0 ? (
        employees.map((employee) => (
          <div key={employee.id} className="mb-5">
            <h2 className="text-white text-lg mb-3">
              Tasks for {employee.firstname} ({employee.email})
            </h2>
            {employee.tasks.length > 0 ? (
              employee.tasks.map((task) => (
                <div
                  key={task.id}
                  className={`mb-2 flex justify-between items-center p-4 rounded ${
                    task.active
                      ? "bg-green-500"
                      : task.completed
                      ? "bg-blue-500"
                      : task.failed
                      ? "bg-red-500"
                      : "bg-yellow-500"
                  }`}
                >
                  <div>
                    <h3 className="text-white font-semibold">{task.title}</h3>
                    <p className="text-gray-200 text-sm">{task.description}</p>
                    <p className="text-gray-400 text-xs">
                      Category: {task.category} | Date: {task.date}
                    </p>
                  </div>
                  <div>
                    <p className="text-white font-bold">
                      {task.active && "Active"}
                      {task.newTask && "New"}
                      {task.completed && "Completed"}
                      {task.failed && "Failed"}
                    </p>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-gray-400">No tasks available.</p>
            )}
          </div>
        ))
      ) : (
        <p className="text-gray-400">No employees or tasks found.</p>
      )}
    </div>
  );
};

export default AllTask;
