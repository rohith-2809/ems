import React from "react";

const TaskListNumbers = ({ data }) => {
  // Data for tasks
  const tasks = [
    {
      count: data.taskNumbers.newTask,
      label: "New Task",
      color: "white",
      bgColor: "bg-yellow-400",
    },
    {
      count: data.taskNumbers.active ,
      label: "In Progress",
      color: "white",
      bgColor: "bg-blue-400",
    },
    {
      count: data.taskNumbers.completed,
      label: "Completed",
      color: "white",
      bgColor: "bg-green-400",
    },
    {
      count: data.taskNumbers.failed,
      label: "Failed",
      color: "white",
      bgColor: "bg-red-400",
    },
  ];

  return (
    <div className="flex flex-wrap mt-10 gap-6 justify-center">
      {tasks.map((task, index) => (
        <div
          key={index}
          className={`rounded-xl h-40 w-full sm:w-[45%] md:w-[30%] lg:w-[22%] py-6 px-9 ${task.bgColor}`}
          style={{ color: task.color }} // Dynamically apply text color
        >
          <h2 className="text-3xl font-semibold">{task.count}</h2>
          <h3 className="text-xl font-medium">{task.label}</h3>
        </div>
      ))}
    </div>
  );
};

export default TaskListNumbers;
