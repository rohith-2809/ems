import React, { useState } from "react";

const CreateTask = () => {
  // State for form fields
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    date: "",
    assignTo: "",
    category: "",
  });

  // Update state when input changes
  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [id]: value,
    }));
  };

  // Handle form submission
  const submitHandler = (e) => {
    e.preventDefault();

    // Validate form inputs
    if (
      !formData.title ||
      !formData.description ||
      !formData.date ||
      !formData.assignTo ||
      !formData.category
    ) {
      alert("All fields are required!");
      return;
    }

    // Log or process the data (replace with your backend logic)
    console.log("Task Created:", formData);

    // Reset form
    setFormData({
      title: "",
      description: "",
      date: "",
      assignTo: "",
      category: "",
    });

    alert("Task created successfully!");
  };

  return (
    <div className="bg-[#1c1c1c] p-6 rounded-lg shadow-md mt-8">
      <h2 className="text-2xl font-bold text-white mb-6">Create a New Task</h2>
      <form onSubmit={submitHandler} className="flex flex-wrap gap-6">
        {/* Task Title */}
        <div className="w-full sm:w-[48%]">
          <label
            htmlFor="title"
            className="block text-sm font-medium text-gray-300 mb-2"
          >
            Task Title
          </label>
          <input
            type="text"
            id="title"
            placeholder="Enter task title"
            value={formData.title}
            onChange={handleChange}
            className="w-full p-3 border border-gray-600 rounded-md bg-[#1c1c1c] text-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-400"
          />
        </div>

        {/* Description */}
        <div className="w-full sm:w-[48%]">
          <label
            htmlFor="description"
            className="block text-sm font-medium text-gray-300 mb-2"
          >
            Description
          </label>
          <textarea
            id="description"
            placeholder="Enter task description"
            rows="4"
            value={formData.description}
            onChange={handleChange}
            className="w-full p-3 border border-gray-600 rounded-md bg-[#1c1c1c] text-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-400"
          ></textarea>
        </div>

        {/* Date */}
        <div className="w-full sm:w-[48%]">
          <label
            htmlFor="date"
            className="block text-sm font-medium text-gray-300 mb-2"
          >
            Date
          </label>
          <input
            type="date"
            id="date"
            value={formData.date}
            onChange={handleChange}
            className="w-full p-3 border border-gray-600 rounded-md bg-[#1c1c1c] text-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-400"
          />
        </div>

        {/* Assign To */}
        <div className="w-full sm:w-[48%]">
          <label
            htmlFor="assignTo"
            className="block text-sm font-medium text-gray-300 mb-2"
          >
            Assign To
          </label>
          <input
            type="text"
            id="assignTo"
            placeholder="Enter employee name"
            value={formData.assignTo}
            onChange={handleChange}
            className="w-full p-3 border border-gray-600 rounded-md bg-[#1c1c1c] text-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-400"
          />
        </div>

        {/* Category */}
        <div className="w-full sm:w-[48%]">
          <label
            htmlFor="category"
            className="block text-sm font-medium text-gray-300 mb-2"
          >
            Category
          </label>
          <input
            type="text"
            id="category"
            placeholder="e.g., Design, Development"
            value={formData.category}
            onChange={handleChange}
            className="w-full p-3 border border-gray-600 rounded-md bg-[#1c1c1c] text-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-400"
          />
        </div>

        {/* Submit Button */}
        <div className="w-full">
          <button
            type="submit"
            className="w-full sm:w-auto px-6 py-3 bg-blue-500 text-white font-medium rounded-md hover:bg-blue-600 transition"
          >
            Create Task
          </button>
        </div>
      </form>
    </div>
  );
};

export default CreateTask;
